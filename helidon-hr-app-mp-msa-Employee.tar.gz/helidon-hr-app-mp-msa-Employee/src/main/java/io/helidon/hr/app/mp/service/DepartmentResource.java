package io.helidon.hr.app.mp.service;

import io.helidon.config.Config;
import io.helidon.hr.app.mp.domain.Department;
import io.helidon.hr.app.mp.domain.Employee;
import io.helidon.hr.app.mp.persistence.EmpDeptRepository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.json.JsonObject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Collection;
import java.util.List;
import java.util.logging.Logger;

@Path("/department")
@ApplicationScoped
public class DepartmentResource {

    private EmpDeptRepository empDeptRepo;
    private static final Logger LOGGER = Logger.getLogger(EmpDeptResource.class.getName());

    //private EmpDeptProvider employeeProvider;

    @Inject
    public DepartmentResource(Config config, EmpDeptProvider anEmployeeProvider) {
      //  employeeProvider = anEmployeeProvider;
        empDeptRepo = EmpDeptRepository.create(config.get("app.drivertype").asString().orElse("Array"), config);
    }
    @Path("/all")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Department> getDepartments() {
        List<Department> depts = empDeptRepo.departments();
        if (depts.size() > 0){
            return depts;
        }
        else {
            throw new WebApplicationException(Response.Status.NOT_FOUND);
        }
    }

    @Path("/{dept}/employees")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Employee> getByDepartment(@PathParam("dept") String dept) {
        LOGGER.fine("getByDepartment");

        List<Employee> emps = empDeptRepo.getByDepartment(dept);
        if (emps != null && emps.size() > 0){
            return emps;
        }
        else {
            throw new WebApplicationException(Response.Status.NOT_FOUND);
        }
    }

    @Path("/{dept}/salary")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Long getDepartmentSalary(@PathParam("dept") String deptId) {
        Department dept = empDeptRepo.getDepartment(deptId);
        if (dept != null) {
            return dept.getTotalSalary();
        }
        else {
            throw new WebApplicationException(Response.Status.NOT_FOUND);
        }
    }

    @Path("/{id}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public JsonObject getFullDept(@PathParam("id") String deptId) {
        JsonObject jsonDept = empDeptRepo.getFullDepartment(deptId);
        if (jsonDept != null) {
            return jsonDept;
        }
        else {
            throw new WebApplicationException(Response.Status.NOT_FOUND);
        }
    }
}
