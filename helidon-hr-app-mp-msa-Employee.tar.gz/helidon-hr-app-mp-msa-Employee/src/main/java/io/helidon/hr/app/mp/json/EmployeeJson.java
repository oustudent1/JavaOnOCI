package io.helidon.hr.app.mp.json;

import io.helidon.hr.app.mp.domain.Department;
import io.helidon.hr.app.mp.domain.Employee;

import javax.json.bind.annotation.JsonbCreator;
import javax.json.bind.annotation.JsonbProperty;
import java.sql.Time;

public class EmployeeJson {
    private long employeeId;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private Time hireDate;
    private Long salary;
    private Long commissionPct;
    private Long departmentId;
   private String jobId;



    public EmployeeJson() {

    }
    @JsonbCreator
    public static EmployeeJson of(@JsonbProperty("id") Long employeeId, @JsonbProperty("first_name") String firstName,
                              @JsonbProperty("last_Name") String lastName, @JsonbProperty("email") String email,
                              @JsonbProperty("phone_Number") String phone, @JsonbProperty("hire_Date") Time hireDate,
                              @JsonbProperty("pay") Long salary, @JsonbProperty("job_title") String jobId,
                              @JsonbProperty("department") Long departmentId) {

        return new EmployeeJson(employeeId, firstName, lastName, email, phone, hireDate, salary, jobId, departmentId);

    }

    public EmployeeJson(Long id, String firstName, String lastName, String email, String phone, Time hireDate,
                    Long salary, String jobId, Long departmentId) {
        employeeId = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phone;
        this.hireDate = hireDate;
        this.salary= salary;
        this.jobId = jobId;
        this.departmentId = departmentId;
    }

}
