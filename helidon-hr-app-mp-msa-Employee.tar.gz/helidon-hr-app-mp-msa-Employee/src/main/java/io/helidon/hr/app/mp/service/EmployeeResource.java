package io.helidon.hr.app.mp.service;


import io.helidon.config.Config;
import io.helidon.hr.app.mp.domain.Department;
import io.helidon.hr.app.mp.domain.Employee;
import io.helidon.hr.app.mp.persistence.EmpDeptRepository;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.StringReader;
import java.sql.Time;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.logging.Logger;

@Path("/employee")
@ApplicationScoped
public class EmployeeResource {
    private EmpDeptRepository empDeptRepo;
    private static final Logger LOGGER = Logger.getLogger(EmpDeptResource.class.getName());

  //  private EmpDeptProvider employeeProvider;

    @Inject
    public EmployeeResource(Config config, EmpDeptProvider anEmployeeProvider) {
     //   employeeProvider = anEmployeeProvider;
        empDeptRepo = EmpDeptRepository.create(config.get("app.drivertype").asString().orElse("Array"), config);
    }


    @Path("/all")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Employee> employees() {
        LOGGER.fine("getAll");
        List<Employee> emps = empDeptRepo.employees();
        if (emps.size() > 0){
            return empDeptRepo.employees();
        }
        else {
            throw new WebApplicationException(Response.Status.NOT_FOUND);
        }


    }

    @Path("/{lastName}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Employee getByLastName(@PathParam("lastName") String lastName) {
        // RespoinseBuilder?
        LOGGER.fine("getByLastName");

        List<Employee> emps = this.empDeptRepo.getByLastName(lastName);
        if (emps.size() > 0){
            return emps.get(0);
        }
        else {
            throw new WebApplicationException(Response.Status.NOT_FOUND);
        }
    }


    @Path("/id/{id}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Employee getEmployeeById(@PathParam("id") String id) {
        LOGGER.fine("getEmployeeById");
        Employee emp = empDeptRepo.getById(id);
        if ( emp != null){
            return emp;
        }
        else {
            throw new WebApplicationException(Response.Status.NOT_FOUND);
        }
    }

    /**
     * Saves a new employee.
     */

    @POST
    @Consumes({MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
    @Produces(MediaType.APPLICATION_JSON)
    public long save(String request) {
        LOGGER.fine("save");
        System.out.println("Request for POST = "+ request);
        /*
         *//*
        need to instantiate the Employee manually because the json fwk can't create a new Employee
        because it requires a department object in the Employee constructor.
         *//*
        JsonReader jsonReader = Json.createReader(new StringReader(request));
        JsonObject jsonObject = jsonReader.readObject();

        // parse Dept
        JsonNumber deptIdJson = jsonObject.getJsonObject("departmentsByDepartmentId").getJsonNumber("departmentId");
        long deptId = deptIdJson.longValue();

        // parse Employee

        //JsonObject empJson = jsonObject.getJsonObject()
        long empId = jsonObject.getJsonNumber("employeeId").longValue();
        String firstName = jsonObject.getString("firstName");
        String lastName = jsonObject.getString("lastName");
        String email = jsonObject.getString("email");

        //get correct date
        String date = jsonObject.getString("hireDate");
        String ymd  = date.substring(0,10);  // extract YYYY-MM-DD from the date
        LocalDate localDate = LocalDate.of(Integer.parseInt(date.substring(0,3)), Integer.parseInt(date.substring(5,7)), Integer.parseInt(date.substring(8,10)));
        java.sql.Date sqlDate = java.sql.Date.valueOf(localDate);
        Time time = new Time(sqlDate.getTime());

        String phone = jsonObject.getString("phoneNumber");
        long salary = jsonObject.getJsonNumber("salary").longValue();
        String jobId = jsonObject.getString("jobId");

        // find dept
        Department theDept = empDeptRepo.getDepartment(Long.toString(deptId));
        // create new "dummy" dept obj for JPA fwk to use to create the employee
        // JPA has issues with the embedded Emps in the Dept, so create  dept without them,- JPA will pull just the dept id -
        Department newDept = new Department(theDept.getDepartmentId(), theDept.getDepartmentName());*/

        // Employee newEmp =  new Employee(empId, firstName,lastName, email ,phone, time, salary, jobId , newDept);
        Employee newEmp = createEmployeeFromJsonRequest(request);
        empDeptRepo.save(newEmp);
        return newEmp.getEmployeeId();
    }


    @PUT
    public void update(String request) {
        LOGGER.fine("update");
        Employee emp = createEmployeeFromJsonRequest(request);
        empDeptRepo.update(emp, Long.toString(emp.getEmployeeId()));
    }

    /**
     * Deletes an existing employee.
     */
    @Path("/{id}")
    @DELETE
    public void delete(@PathParam("id") String id) {
        LOGGER.fine("delete");
        empDeptRepo.deleteById(id);
    }

    private Employee createEmployeeFromJsonRequest(String request){
        JsonReader jsonReader = Json.createReader(new StringReader(request));
        JsonObject jsonObject = jsonReader.readObject();

        // parse Dept
        JsonNumber deptIdJson = jsonObject.getJsonObject("departmentsByDepartmentId").getJsonNumber("departmentId");
        long deptId = deptIdJson.longValue();

        // parse Employee

        //JsonObject empJson = jsonObject.getJsonObject()
        long empId = jsonObject.getJsonNumber("employeeId").longValue();
        String firstName = jsonObject.getString("firstName");
        String lastName = jsonObject.getString("lastName");
        String email = jsonObject.getString("email");

        //get correct date
        String date = jsonObject.getString("hireDate");
        String ymd  = date.substring(0,10);  // extract YYYY-MM-DD from the date
        LocalDate localDate = LocalDate.of(Integer.parseInt(date.substring(0,3)), Integer.parseInt(date.substring(5,7)), Integer.parseInt(date.substring(8,10)));
        java.sql.Date sqlDate = java.sql.Date.valueOf(localDate);
        Time time = new Time(sqlDate.getTime());

        String phone = jsonObject.getString("phoneNumber");
        long salary = jsonObject.getJsonNumber("salary").longValue();
        String jobId = jsonObject.getString("jobId");

        // find dept
        Department theDept = empDeptRepo.getDepartment(Long.toString(deptId));
        // create new "dummy" dept obj for JPA fwk to use to create the employee
        // JPA has issues with the embedded Emps in the Dept, so create  dept without them,- JPA will pull just the dept id -
        Department newDept = new Department(theDept.getDepartmentId(), theDept.getDepartmentName());

        return new Employee(empId, firstName,lastName, email ,phone, time, salary, jobId , newDept);
    }
}
