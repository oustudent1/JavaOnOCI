package io.helidon.hr.app.mp.persistence;

import io.helidon.config.Config;
import io.helidon.hr.app.mp.domain.Department;
import io.helidon.hr.app.mp.domain.Employee;

import javax.json.JsonObject;
import java.util.List;

public interface EmpDeptRepository {
    public static EmpDeptRepository create(String driverType, Config config) {
        switch (driverType) {
            case "Array":
                System.out.println("DriverType - Array");
                return new EmpDeptRepositoryImpl();
            case "Oracle":
                System.out.println("DriverType - Oracle");
                return new EmpDeptRepositoryImplDB(); // normally we'll pass a config file with database details
            default:
                // Array is default
                System.out.println("DriverType - Default = Array");
                return new EmpDeptRepositoryImpl();
        }
    }

    public List<Employee> employees();

    public List<Employee> getByLastName(String lastName);

    public List<Employee> getByDepartment(String department);

    // public List<Employee> getByDepartment(int deptId);
    public Employee save(Employee employee); // Add new employee

    public Employee update(Employee updatedEmployee, String id);

    public void deleteById(String id);

    public Employee getById(String id);

    public boolean isIdFound(String id);

    public int getEmployeeCount();

    // department api

    public List<Department> departments();

    public Department getDepartment(String dept);

    public JsonObject getFullDepartment(String deptId);

    public List<Employee> getEmployees(String dept);

    public void transferEmployee (String fromDept, String toDept);

    public long getTotalSalary(String dept);
}
