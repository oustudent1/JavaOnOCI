package io.helidon.hr.app.mp.persistence;

import io.helidon.hr.app.mp.domain.Department;
import io.helidon.hr.app.mp.domain.Employee;

import javax.json.*;
import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.json.bind.JsonbConfig;
import javax.json.spi.JsonProvider;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EmpDeptRepositoryImplDB  {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("hr");
    EntityManager em = emf.createEntityManager();

    public EmpDeptRepositoryImplDB() {
    }

    public List<Employee> employees() {
        Query query = em.createQuery("select e from Employee e");
        return query.getResultList();
    }

      public List<Employee> getByLastName(String lastName) {
        Query query = em.createQuery("select e from Employee e where e.lastName = :lastName");
        return query.setParameter("lastName", lastName).getResultList();
    }

      public List<Employee> getByDepartment(String deptId) {
        Department dept = getDepartment(deptId);
        if (dept != null) {
            return dept.getEmployeesByDepartmentId();
        }
       else {
           return null;
        }
    }

        public JsonObject getFullDepartment(String deptId) {
        Department dept = getDepartment(deptId);
        if (dept != null) {
            List<Employee> emps = dept.getEmployeesByDepartmentId();
            if (emps != null && emps.size() > 0) {
                JsonArrayBuilder empArrayBuilder = Json.createArrayBuilder();
                for (Employee e : emps) {
                    JsonObject json = Json.createObjectBuilder()
                            .add("id", e.getEmployeeId())
                            .add("firstName", e.getFirstName())
                            .add("lastName", e.getLastName())
                            .add("email", e.getEmail())
                            .build();
                    empArrayBuilder.add(json);
                }
                JsonArray empArray = empArrayBuilder.build();
                JsonObject deptValue = Json.createObjectBuilder()
                        .add("departmentId", dept.getDepartmentId())
                        .add("name", dept.getDepartmentName())
                        .add("employees", empArray)
                        .build();
//                System.out.println("Model = " + deptValue);

                return deptValue;
            }
        }
        return null;
    }

       public Employee save(Employee employee) {
        em.getTransaction().begin();
        em.persist(employee);
        em.getTransaction().commit();
        return employee;
    }

      public Employee update(Employee updatedEmployee, String id) {
        Employee employee = em.find(Employee.class, Long.parseLong(id));
        em.getTransaction().begin();
        em.merge(updatedEmployee);
        em.getTransaction().commit();
        return null;
    }

      public void deleteById(String id) {
        em.getTransaction().begin();
        Employee employee = em.find(Employee.class, Long.parseLong(id));
        em.remove(employee);
        em.getTransaction().commit();

    }

       public Employee getById(String id) {
        Employee e = em.find(Employee.class, Long.parseLong(id));
        /*long idAsLong = Long.parseLong(id);
        Query query = em.createQuery("select e from Employee e where e.employeeId = :id");
        List<Employee> emps = query.setParameter("id", idAsLong).getResultList();*/
        return e; //emps.get(0);
    }


    public List<Department> departments() {
        Query query = em.createQuery("select d from Department d");
        return query.getResultList();
    }

    public long getTotalSalary(String deptId) {
        Department d = em.find(Department.class, Long.parseLong(deptId));
        return d.getTotalSalary();
    }

        public Department getDepartment(String deptId) {
        Department d = em.find(Department.class, Long.parseLong(deptId));
        return d;
    }

}
