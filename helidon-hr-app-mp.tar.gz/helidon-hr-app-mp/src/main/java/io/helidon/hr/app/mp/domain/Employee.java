package io.helidon.hr.app.mp.domain;

import javax.json.bind.annotation.JsonbCreator;
import javax.json.bind.annotation.JsonbProperty;
import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.*;
import java.sql.Time;
import java.util.Objects;
@Entity
@Table(name = "EMPLOYEES", schema = "HR")
public class Employee {
    private long employeeId;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private Time hireDate;
    private Long salary;
    private Long commissionPct;
    private Long departmentId;
    private Department departmentsByDepartmentId;
    private String jobId;



    public Employee() {

    }
    @JsonbCreator
    public static Employee of(@JsonbProperty("employeeId") Long employeeId, @JsonbProperty("firstName") String firstName,
                              @JsonbProperty("lastName") String lastName, @JsonbProperty("email") String email,
                              @JsonbProperty("phoneNumber") String phone, @JsonbProperty("hireDate") Time hireDate,
                              @JsonbProperty("salary") Long salary, @JsonbProperty("jobId") String jobId,
                              @JsonbProperty("department") Department departmentsByDepartmentId) {

        return new Employee(employeeId, firstName, lastName, email, phone, hireDate, salary, jobId, departmentsByDepartmentId);

    }

    public Employee(Long id, String firstName, String lastName, String email, String phone, Time hireDate,
                    Long salary, String jobId, Department departmentsByDepartmentId) {
        employeeId = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phone;
        this.hireDate = hireDate;
        this.salary= salary;
        this.jobId = jobId;
        this.departmentsByDepartmentId = departmentsByDepartmentId;
    }


    @Id
    @Column(name = "EMPLOYEE_ID")
    public long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(long employeeId) {
        this.employeeId = employeeId;
    }

    @Basic
    @Column(name = "FIRST_NAME")
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Basic
    @Column(name = "LAST_NAME")
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Basic
    @Column(name = "EMAIL")
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Basic
    @Column(name = "PHONE_NUMBER")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Basic
    @Column(name = "HIRE_DATE")
    public Time getHireDate() {
        return hireDate;
    }

    public void setHireDate(Time hireDate) {
        this.hireDate = hireDate;
    }

    @Basic
    @Column(name = "SALARY")
    public Long getSalary() {
        return salary;
    }

    public void setSalary(Long salary) {
        this.salary = salary;
    }

    @Basic
    @Column(name = "COMMISSION_PCT")
    public Long getCommissionPct() {
        return commissionPct;
    }

    public void setCommissionPct(Long commissionPct) {
        this.commissionPct = commissionPct;
    }
    @Basic
    @Column(name = "JOB_ID")
    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

/*
    @Basic
    @Column(name = "DEPARTMENT_ID")*/
/*    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }*/

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return employeeId == employee.employeeId &&
                Objects.equals(firstName, employee.firstName) &&
                Objects.equals(lastName, employee.lastName) &&
                Objects.equals(email, employee.email) &&
                Objects.equals(phoneNumber, employee.phoneNumber) &&
                Objects.equals(hireDate, employee.hireDate) &&
                Objects.equals(salary, employee.salary) &&
                Objects.equals(commissionPct, employee.commissionPct);
    }

    @Override
    public int hashCode() {
        return Objects.hash(employeeId, firstName, lastName, email, phoneNumber, hireDate, salary, commissionPct);
    }

    @Override
    public String toString() {
        return "Employee{" +
                "employeeId=" + employeeId +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", hireDate=" + hireDate +
                ", salary=" + salary +
                ", commissionPct=" + commissionPct +
                ", departmentId=" + departmentId +
                ", jobId=" + jobId +
                ", departmentsByDepartmentId=" + departmentsByDepartmentId +
                '}';
    }
//@JsonbTransient
    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn( name = "DEPARTMENT_ID", referencedColumnName = "DEPARTMENT_ID", table = "EMPLOYEES")
    public Department getDepartmentsByDepartmentId() {
       // System.out.println("dept by id from Emp = " + departmentsByDepartmentId);

        return departmentsByDepartmentId;
    }

    public void setDepartmentsByDepartmentId(Department departmentsByDepartmentId) {
        this.departmentsByDepartmentId = departmentsByDepartmentId;
    }
}
