package duke.labs.rs.service;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import java.io.BufferedReader;

import java.io.InputStreamReader;

import org.apache.http.client.HttpClient;

import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.sql.*;

public class TestJDBC {

    static final String DB_URL = "jdbc:mysql://172.17.0.2/dukedb";
    static final String USER = "oracle";
    static final String PASS = "oracle_4U";
    static final String QUERY = "SELECT * FROM EXPERIMENTS";

    public static void main(String[] args) {
        // Open a connection
//        System.out.println("*** Begin JDBC Test Execution ");
//        try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
//            Statement stmt = conn.createStatement();
//            ResultSet rs = stmt.executeQuery(QUERY)) {
//            // Extract data from result set
//            while (rs.next()) {
//                // Retrieve by column name
//                System.out.print("ID: " + rs.getInt("id"));
//                System.out.print(", Task: " + rs.getString("task"));
//                System.out.println();
//
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        System.out.println("*** End JDBC Test Execution ");
// Test REST client access to Dukelabs
        try {
            System.out.println("\n============JERSEY Dukelabs Response============");
            Client client = Client.create();
            WebResource webResource2 = client.resource("http://172.17.0.2:8080/experiment/test");
            ClientResponse response2 = webResource2.accept("application/json").get(ClientResponse.class);
            if (response2.getStatus() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + response2.getStatus());
            }

            String output2 = response2.getEntity(String.class);
            System.out.println("\n============Dukelabs Response============");
            System.out.println(output2);

        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("\n============HTTP Dukelabs Response============");
        DefaultHttpClient httpclient = new DefaultHttpClient();
        try {
            // specify the host, protocol, and port
            HttpHost target = new HttpHost("172.17.0.2", 8080, "http");

            // specify the get request
            HttpGet getRequest = new HttpGet("/experiment/test");

            System.out.println("executing request to " + target);

            HttpResponse httpResponse = httpclient.execute(target, getRequest);
            HttpEntity entity = httpResponse.getEntity();

            System.out.println("----------------------------------------");
            System.out.println(httpResponse.getStatusLine());
            Header[] headers = httpResponse.getAllHeaders();
            for (int i = 0; i < headers.length; i++) {
                System.out.println(headers[i]);
            }
            System.out.println("----------------------------------------");

            if (entity != null) {
                System.out.println(EntityUtils.toString(entity));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // When HttpClient instance is no longer needed,
            // shut down the connection manager to ensure
            // immediate deallocation of all system resources
            httpclient.getConnectionManager().shutdown();
        }

    }
}