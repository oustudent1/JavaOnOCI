DROP TABLE if exists Measurements;
DROP TABLE if exists Experiments;
CREATE TABLE Experiments
		( 
			id INT auto_increment primary key, 
			task VARCHAR(250) NOT NULL,
			start_time TIMESTAMP, 
			end_time TIMESTAMP,
			complete BOOLEAN,
			owner VARCHAR(250) NOT NULL DEFAULT 'DUKE'	);			
CREATE TABLE Measurements 
	 ( id INT auto_increment primary key,
			value DECIMAL(10, 3) NOT NULL,
			unit VARCHAR(10) NOT NULL,
			time BIGINT NOT NULL,
			exp_id INTEGER NOT NULL, 
			FOREIGN KEY (exp_id)
			REFERENCES Experiments (id)
		);
