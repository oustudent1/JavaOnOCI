CREATE SCHEMA `dukedb` ;
use dukedb;
CREATE USER 'oracle'@'%' IDENTIFIED BY 'oracle_4U';
GRANT ALL PRIVILEGES ON dukedb . * TO 'oracle'@'%';
CREATE TABLE EXPERIMENTS
		( 
			id INT auto_increment primary key, 
			task VARCHAR(250) NOT NULL,
			start_time TIMESTAMP, 
			end_time TIMESTAMP,
			complete BOOLEAN,
			owner VARCHAR(250) NOT NULL DEFAULT 'DUKE'	);			
CREATE TABLE MEASUREMENTS 
	 ( id INT auto_increment primary key,
			value DECIMAL(10, 3) NOT NULL,
			unit VARCHAR(10) NOT NULL,
			time BIGINT NOT NULL,
			exp_id INTEGER NOT NULL, 
			FOREIGN KEY (exp_id)
			REFERENCES EXPERIMENTS (id)
		);
ALTER TABLE EXPERIMENTS AUTO_INCREMENT=100; 
-- Experiments data
INSERT INTO EXPERIMENTS (task, start_time, end_time, complete) VALUES('Measure temperature change', '2020-11-30 12:00:00', CURRENT_TIMESTAMP, true);
INSERT INTO EXPERIMENTS (task, start_time, end_time, complete) VALUES('Changes in global average surface temperature', '2015-12-31 23:59:59', null, false);

-- Measurements data
INSERT INTO MEASUREMENTS (value, unit, time, exp_id) VALUES(291.25, 'K', 0, 100);
INSERT INTO MEASUREMENTS (value, unit, time, exp_id) VALUES(289.55, 'K', 300, 100);
INSERT INTO MEASUREMENTS (value, unit, time, exp_id) VALUES(285.55, 'K', 600, 100);
INSERT INTO MEASUREMENTS (value, unit, time, exp_id) VALUES(283.45, 'K', 900, 100);

INSERT INTO MEASUREMENTS (value, unit, time, exp_id) VALUES(0.99, 'C', 600, 101);
INSERT INTO MEASUREMENTS (value, unit, time, exp_id) VALUES(0.85, 'C', 1200, 101);
INSERT INTO MEASUREMENTS (value, unit, time, exp_id) VALUES(0.93, 'C', 1500, 101);
INSERT INTO MEASUREMENTS (value, unit, time, exp_id) VALUES(1.02, 'C', 1700, 101);
INSERT INTO MEASUREMENTS (value, unit, time, exp_id) VALUES(0.90, 'C', 2000, 101);
