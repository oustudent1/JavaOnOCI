package io.helidon.hr.app.mp.persistence;

//import javax.json.bind.Jsonb;
//import javax.json.bind.JsonbBuilder;
//import javax.json.bind.JsonbConfig;


import io.helidon.hr.app.mp.domain.Department;
import io.helidon.hr.app.mp.domain.Employee;

import javax.json.JsonObject;
import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.json.bind.JsonbConfig;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public final class EmpDeptRepositoryImpl implements EmpDeptRepository {

    private final List<Employee> employeeList = new ArrayList<Employee>();
    private final List<Department> departmentList = new ArrayList<Department>();

    public EmpDeptRepositoryImpl() {
        JsonbConfig config = new JsonbConfig().withFormatting(Boolean.TRUE);

        Jsonb jsonb = JsonbBuilder.create(config);

        employeeList.addAll(jsonb.fromJson(EmpDeptRepositoryImpl.class.getResourceAsStream("/employees.json"),
                new ArrayList<Employee>() { }.getClass().getGenericSuperclass()));
        System.out.println("eList1 =" + employeeList);

        departmentList.addAll(jsonb.fromJson(EmpDeptRepositoryImpl.class.getResourceAsStream("/departments.json"),
                new ArrayList<Department>() { }.getClass().getGenericSuperclass()));
        System.out.println("eList2 =" + departmentList);

    }

    @Override
    public List<Employee> employees() {
        return employeeList;
    }

    @Override
    public List<Employee> getByLastName(String name) {

        System.out.println("Get by last Name MatchList1 " );
        List<Employee> matchList = employeeList.stream().filter((e) -> (e.getLastName().contains(name)))
                .collect(Collectors.toList());
        System.out.println("Get by last Name MatchList2 " + matchList);
        return matchList;
    }


/*
    @Override
    public List<Employee> getByDepartment(String deptId) {
        List<Employee> matchList = eList.stream()
                .filter((e) -> (e.getDepartmentId().contains(deptId))
                .collect(Collectors.toList());

        return matchList;
    }
*/

    @Override
    public List<Employee> getByDepartment(String department) {
     /*   List<Employee> matchList = employeeList.stream().filter((e) -> (e.getDepartmentsByEmployeeId().contains(department)))
                .collect(Collectors.toList());*/

        return null;
    }

    public Employee save(Employee employee) {
/*        Employee nextEmployee = Employee.of(null, employee.getFirstName(), employee.getLastName(),
                employee.getEmail(), employee.getPhone(), employee.getBirthDate(),
                employee.getTitle(), employee.getDepartment());*/
        employeeList.add(employee);
        return employee;
    }

    @Override
    public Employee update(Employee updatedEmployee, String id) {
        deleteById(id);
/*        Employee e = Employee.of(id, updatedEmployee.getFirstName(), updatedEmployee.getLastName(),
                updatedEmployee.getEmail(), updatedEmployee.getPhone(), updatedEmployee.getBirthDate(),
                updatedEmployee.getTitle(), updatedEmployee.getDepartment());*/
        employeeList.add(updatedEmployee);
        return updatedEmployee;
    }

    @Override
    public void deleteById(String id) {
/*        int matchIndex;
        matchIndex = eList.stream()
                .filter(e -> e.getId().equals(id))
                .findFirst()
                .map(e -> eList.indexOf(e)).get();*/
        employeeList.remove(getById(id));
    }

    @Override
    public Employee getById(String id) {
        Employee match;
        match = employeeList.stream().filter(e -> Long.toString(e.getEmployeeId()).equals(id)).findFirst().get();
        return match;
    }

    @Override
    public boolean isIdFound(String id) {
        return false;
    }

    @Override
    public int getEmployeeCount() {
        return employeeList.size();
    }

    @Override
    public Department getDepartment(String dept) {
        Department theDept = null;
        for (Department d : departmentList) {
            if ((Long.toString(d.getDepartmentId()).equals(dept))) {
                theDept = d;
                break;
            }
        }
        return theDept;
    }

    @Override
    public JsonObject getFullDepartment(String deptId) {
        return null;
    }

    //Dept API

    @Override
    public List<Employee> getEmployees(String dept) {
        return null;
    }

    @Override
    public void transferEmployee(String fromDept, String toDept) {

    }

    @Override
    public long getTotalSalary(String dept) {
        return 0;
    }


    public List<Department> departments() {
        return departmentList;
    }

}