package io.helidon.hr.app.mp.service;

import org.eclipse.microprofile.config.inject.ConfigProperty;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.concurrent.atomic.AtomicReference;

@ApplicationScoped
public class EmpDeptProvider {
    private final AtomicReference<String> message = new AtomicReference<>();

    /**
     * Create a new employee provider, reading the message from configuration.
     *
     * @param message greeting to use
     */
    @Inject
    public EmpDeptProvider(@ConfigProperty(name = "app.hr") String message) {
        this.message.set(message);
    }

    String getMessage() {
        return message.get();
    }

    void setMessage(String message) {
        this.message.set(message);
    }
}
