package io.helidon.hr.app.mp.persistence;

import io.helidon.hr.app.mp.domain.Department;
import io.helidon.hr.app.mp.domain.Employee;

import javax.json.*;
import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.json.bind.JsonbConfig;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.sql.Time;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestJPA {

    public static void main(String[] args) {
        System.out.println("Test JPA");
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("hr");
        EntityManager em = emf.createEntityManager();

        Department dept = new Department(1000, "Sample");
        // test save
/*      em.getTransaction( ).begin( );
        em.persist(dept);
        em.getTransaction( ).commit( );
*/
/*        em.getTransaction( ).begin( );
        dept.setDepartmentName("Sample Updated");
        em.getTransaction( ).commit( );

        Department dept1 = em.find( Department.class, Long.parseLong("10") );
        Department dept2 = new Department(1000, " merged updated");
        em.getTransaction( ).begin( );
        em.merge(dept2);
        //dept.setDepartmentName("Sample Updated");
        em.getTransaction( ).commit( );*/

       /* em.getTransaction( ).begin( );
        long empId = 1000;
        dept = em.find(Department.class, empId);
        em.remove(dept);
        em.getTransaction( ).commit( );*/



        //   Map<String, Department> config = new HashMap<String, Department>();
        //  JsonBuilderFactory factory = Json.createBuilderFactory(config);

        //  JsonObject object = (JsonObject) Json.createObjectBuilder();



        // test creating new employee
        //employeeId, firstName, lastName, email, phone, hireDate, salary, departmentsByDepartmentId)
        Department dept1 = em.find(Department.class, new Long(60));
        System.out.println("Total salary = " + dept1.getTotalSalary());

        Employee newEmp = new Employee(new Long(1023), "h", "t", "hst11", "415", new Time(new Long(10000)), new Long(1200), "AD_VP", dept1);
        newEmp.setDepartmentsByDepartmentId(dept1);

     /*   em.getTransaction( ).begin( );
        em.persist(newEmp);
        em.getTransaction( ).commit( );


        long departmentAsLong = Long.parseLong("10");
        Query query = em.createQuery("select d from Department d where d.departmentId = :departmentAsLong");
         dept = (Department) query.setParameter("departmentAsLong", departmentAsLong).getResultList().get(0);
        List<Employee> emps = dept.getEmployeesByDepartmentId();
        Collection eColl = emps;

        JsonArrayBuilder empArrayBuilder = Json.createArrayBuilder();
        for (Employee e : emps) {
            JsonObject json = Json.createObjectBuilder()
                    .add("id", e.getEmployeeId())
                    .add("firstName", e.getFirstName())
                    .add("lastName", e.getLastName())
                    .add("email", e.getEmail())
                    .build();

            empArrayBuilder.add(json);
            ;
        }
        JsonArray empArray = empArrayBuilder.build();

        JsonObject deptValue = Json.createObjectBuilder()
                .add("departmentId", dept.getDepartmentId())
                .add("name", dept.getDepartmentName())
                .add("employees", empArray)
                .build();
        JsonObject empsValue = null;

        JsonArray value = null;




        value = Json.createArrayBuilder()
                .add(Json.createObjectBuilder()
                        .add("type", "home")
                        .add("number", "212 555-1234"))
                .add(Json.createObjectBuilder()
                        .add("type", "fax")
                        .add("number", "646 555-4567"))
                .build();*/

/*

        Map<String, Department> config = new HashMap<String, Department>();
        JsonBuilderFactory factory = Json.createBuilderFactory(config);
*/



        // JsonObject fullDept = Json.createObjectBuilder().add(deptValue);
/* JsonObject value = Json.createObjectBuilder()
     .add("firstName", "John")
     .add("lastName", "Smith")
     .add("age", 25)
     .add("address", Json.createObjectBuilder()
         .add("streetAddress", "21 2nd Street")
         .add("city", "New York")
         .add("state", "NY")
         .add("postalCode", "10021"))
     .add("phoneNumber", Json.createArrayBuilder()
         .add(Json.createObjectBuilder()
             .add("type", "home")
             .add("number", "212 555-1234"))
         .add(Json.createObjectBuilder()
             .add("type", "fax")
             .add("number", "646 555-4567")))
     .build();*/

      //  System.out.println("Json = " + deptValue + "  " + empArray);

        //  Query query = em.createQuery("select e from Employee e where e.departmentId = :departmentAsLong");
        /*Query query = em.createQuery("select d from Department d where d.departmentId = 10");
         *//*List<Employee> emps*//* Department d = (Department)query.getResultList().get(0);//query.setParameter("departmentAsLong", departmentAsLong).getResultList();

        Collection<Employee> emps = d.getEmployeesByDepartmentId();
       // System.out.println(emps);

        Jsonb jsonb = JsonbBuilder.create();

        String e1 = jsonb.toJson(emps);

        String d1 = jsonb.toJson(d);
        System.out.println(d1 + e1);
*/
/*        Query deptQuery = em.createQuery("select d from Department d where d.departmentId = 10");
        List<Department> depts = deptQuery.getResultList();
        for (Department d : depts){
            System.out.println(d);

           // Jsonb jsonb = JsonbBuilder.newBuilder("io.helidon.hr.app.mp.domain.Department").build();
            Jsonb jsonb = JsonbBuilder.create();
            String j = jsonb.toJson(d);
            System.out.println(j);

        Query eQuery = em.createQuery("select e from Employee e");
        List<Employee> emps = eQuery.getResultList();
        for (Employee e : emps) {
            System.out.println(e.getFirstName() + "   " + ((e.getDepartmentsByDepartmentId() != null) ? e.getDepartmentsByDepartmentId().getDepartmentName() : " ** No Dept"));

        }*/
        //  Department d = e.getDepartmentsByDepartmentId();
           /* System.out.println(e.getFirstName() + "   " + ( (e.getDepartmentId() != null) ? e.getDepartmentId(): " ** No Dept"));

            System.out.println(e.getDepartmentId());
*/
    /*    Query eQuery = em.createQuery("select e from Employee e");
        List<Employee> emps = eQuery.getResultList();
        Employee e = emps.get(0);
        System.out.println("Emps = "+ e.getFirstName() + "   " + ((e.getDepartmentsByDepartmentId() != null)? e.getDepartmentsByDepartmentId().getDepartmentName() :" ** No Dept"));
        Department d = e.getDepartmentsByDepartmentId();
        System.out.println(d);*/



       /* for (Employee e: emps){
            System.out.println(e.getFirstName() + "   " + ((e.getDepartmentsByDepartmentId() != null)? e.getDepartmentsByDepartmentId().getDepartmentName() :" ** No Dept"));
           Department d = e.getDepartmentsByDepartmentId();
            System.out.println(d);
        }*/
/*
        Query dQuery = em.createQuery("select d from Department d");
        List<Department> depts = dQuery.getResultList();

        for (Department d: depts){
            System.out.println("Dept = " + d.getDepartmentName());
            Collection<Employee> emps2 = d.getEmployeesByDepartmentId();
            for (Employee e: emps2){
                System.out.println("Emp = " + e.getFirstName());
            }
            System.out.println();
        }*/


        // }

    }
}
